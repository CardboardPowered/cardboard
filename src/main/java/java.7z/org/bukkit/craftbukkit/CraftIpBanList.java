package org.bukkit.craftbukkit;

import java.util.Date;
import java.util.Set;

import org.bukkit.BanEntry;
import org.bukkit.BanList;

public class CraftIpBanList implements BanList {

    @Override
    public BanEntry addBan(String arg0, String arg1, Date arg2, String arg3) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Set<BanEntry> getBanEntries() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public BanEntry getBanEntry(String arg0) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean isBanned(String arg0) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void pardon(String arg0) {
        // TODO Auto-generated method stub
    }

}
