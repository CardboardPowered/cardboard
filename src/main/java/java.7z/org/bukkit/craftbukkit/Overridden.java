package org.bukkit.craftbukkit;

public @interface Overridden {
    // TODO auto-generated
}