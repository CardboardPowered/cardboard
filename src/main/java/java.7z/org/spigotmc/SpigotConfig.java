package org.spigotmc;

public class SpigotConfig {
}