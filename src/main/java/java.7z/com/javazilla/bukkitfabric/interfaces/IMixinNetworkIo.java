package com.javazilla.bukkitfabric.interfaces;

public interface IMixinNetworkIo {

    public void acceptConnections();

}