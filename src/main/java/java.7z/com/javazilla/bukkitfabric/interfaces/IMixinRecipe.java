package com.javazilla.bukkitfabric.interfaces;

import org.bukkit.inventory.Recipe;

public interface IMixinRecipe {

    public Recipe toBukkitRecipe();

}