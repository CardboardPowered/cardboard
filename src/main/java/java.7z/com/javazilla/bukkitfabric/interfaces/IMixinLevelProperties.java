package com.javazilla.bukkitfabric.interfaces;

public interface IMixinLevelProperties {

    public void checkName(String name);

}