package com.javazilla.bukkitfabric.interfaces;

import org.bukkit.Chunk;

public interface IMixinChunk {

    public Chunk getBukkitChunk();

}