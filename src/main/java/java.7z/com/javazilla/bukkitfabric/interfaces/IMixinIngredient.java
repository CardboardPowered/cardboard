package com.javazilla.bukkitfabric.interfaces;

public interface IMixinIngredient {

    public boolean getExact_BF();

    public void setExact_BF(boolean value);

}