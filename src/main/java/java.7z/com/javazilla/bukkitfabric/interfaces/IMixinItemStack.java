package com.javazilla.bukkitfabric.interfaces;

public interface IMixinItemStack {
}