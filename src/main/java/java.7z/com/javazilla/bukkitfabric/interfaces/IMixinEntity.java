package com.javazilla.bukkitfabric.interfaces;

import org.bukkit.entity.Entity;

public interface IMixinEntity {

    public Entity getBukkitEntity();

}