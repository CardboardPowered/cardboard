package com.javazilla.bukkitfabric.interfaces;

public interface IMixinLockableContainerBlockEntity {

    public org.bukkit.Location getLocation();

}