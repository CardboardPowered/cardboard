package com.javazilla.bukkitfabric;


/**
 * Automatically generated file containing build version information.
 */
public class GitVersion {
	public static final String MAVEN_GROUP = "com.javazilla";
	public static final String MAVEN_NAME = "BukkitFabric";
	public static final String VERSION = "1.16.3";
	public static final int GIT_REVISION = 106;
	public static final String GIT_SHA = "c8c5e56a78674cda80f6a194e9f010881b7cafdf";
	public static final String GIT_DATE = "2020-09-09T21:23:48Z";
	public static final String BUILD_DATE = "2020-09-11T01:00:27Z";
	public static final long BUILD_UNIX_TIME = 1599786027776L;
}