package com.javazilla.bukkitfabric.nms;

import org.objectweb.asm.tree.ClassNode;

//import net.gudenau.minecraft.asm.api.v0.Identifier;
//import net.gudenau.minecraft.asm.api.v0.Transformer;

public class BukkitFabricTransformer {//implements Transformer {

    /*public Identifier TRANSFORMER_ID = new Identifier("bukkit", "nmsremapper");

    @Override
    public Identifier getName() {
        return TRANSFORMER_ID;
    }

    @Override
    public boolean handlesClass(String name, String transformedName) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean transform(ClassNode classNode, Flags flags) {
        System.out.println("CLASSNODE NAME: " + classNode.name);
        return false;
    }*/

}
