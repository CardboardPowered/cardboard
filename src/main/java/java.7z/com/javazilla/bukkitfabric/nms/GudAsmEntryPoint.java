package com.javazilla.bukkitfabric.nms;

//import net.gudenau.minecraft.asm.api.v0.AsmInitializer;
//import net.gudenau.minecraft.asm.api.v0.AsmRegistry;

public class GudAsmEntryPoint {//implements AsmInitializer {

    /*@Override
    public void onInitializeAsm() {
        AsmRegistry.getInstance().registerTransformer(new BukkitFabricTransformer());
    }*/

}