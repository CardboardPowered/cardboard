package com.fungus_soft.bukkitfabric.interfaces;

import org.bukkit.entity.Entity;

public interface IMixinEntity {

    public Entity getBukkitEntity();

}