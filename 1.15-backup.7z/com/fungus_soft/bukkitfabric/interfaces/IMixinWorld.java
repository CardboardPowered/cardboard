package com.fungus_soft.bukkitfabric.interfaces;

import org.bukkit.craftbukkit.CraftWorld;

public interface IMixinWorld {

    public CraftWorld getCraftWorld();

}