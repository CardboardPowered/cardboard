package com.fungus_soft.bukkitfabric.interfaces;

public interface IMixinLevelProperties {

    public void checkName(String name);

}