package com.fungus_soft.bukkitfabric.interfaces;

public interface IMixinRegistryTagContainer {

    public int getVersion();

}