package com.fungus_soft.bukkitfabric.interfaces;

public interface IMixinNetworkIo {

    public void acceptConnections();

}