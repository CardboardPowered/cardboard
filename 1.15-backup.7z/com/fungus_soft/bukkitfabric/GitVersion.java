package com.fungus_soft.bukkitfabric;


/**
 * Automatically generated file containing build version information.
 */
public class GitVersion {
	public static final String MAVEN_GROUP = "com.fungus_soft";
	public static final String MAVEN_NAME = "BukkitFabric";
	public static final String VERSION = "1.15.2";
	public static final int GIT_REVISION = 37;
	public static final String GIT_SHA = "b03b28553801ec02c7339b6247b2057fe7a9c664";
	public static final String GIT_DATE = "2020-06-14T04:58:46Z";
	public static final String BUILD_DATE = "2020-06-14T05:45:21Z";
	public static final long BUILD_UNIX_TIME = 1592113521597L;
}